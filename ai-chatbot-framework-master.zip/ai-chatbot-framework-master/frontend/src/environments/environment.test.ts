export const environment = {
  production: true,
  ikyBackend: "http://localhost:8080/"
};
