def get_dynamic_extensions(self, *args, **kwargs):
    pass
